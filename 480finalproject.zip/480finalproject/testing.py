from training import parse_sgf, build_final_board, extract_game_result, sgf_coordinate_to_index
import glob
import numpy as np
import joblib
from sklearn.metrics import classification_report, accuracy_score

# 确保下面的函数定义与你在 `training.py` 中的定义一致:
# 读取测试集SGF文件，提取棋盘特征和结果
def process_test_sgf_files(test_sgf_directory):
    test_sgf_files = glob.glob(f'{test_sgf_directory}/**/*.sgf', recursive=True)
    X_test = []
    y_test = []
    for sgf_file in test_sgf_files:
        with open(sgf_file, 'r') as file:
            content = file.read()
            moves = parse_sgf(content)
            final_board = build_final_board(moves)
            X_test.append(final_board.flatten())  # Flatten the board to 1D array
            game_result = extract_game_result(content)
            y_test.append(game_result)
    return np.array(X_test), np.array(y_test)

# 测试数据的路径
test_sgf_directory = '2026'

# 处理测试数据
X_test, y_test = process_test_sgf_files(test_sgf_directory)
# 加载训练好的随机森林模型
rf_classifier = joblib.load('random_forest_model.joblib')

# 使用模型进行预测
y_pred = rf_classifier.predict(X_test)

# 计算并打印准确度和其他性能指标
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")
print("Classification Report:\n", classification_report(y_test, y_pred, zero_division=0))

