import glob
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib
# SGF文件中定义棋子的字符到我们棋盘数组的映射
sgf_to_array = {
    'B': 1,  # Black stone
    'W': -1, # White stone
}

def sgf_coordinate_to_index(coord):
    """
    Convert an SGF coordinate to a 0-indexed board coordinate, accounting for the skipped 'I'.
    """
    return ord(coord.lower()) - ord('a') if coord.lower() < 'i' else ord(coord.lower()) - ord('a') - 1

def parse_sgf(sgf_content):
    """
    Parse the SGF content and return the sequence of moves, adjusting for the 'i' skip in coordinates.
    """
    moves = []
    properties = sgf_content.split(';')[1:]  # Split and ignore the game info (first part)
    for prop in properties:
        if prop.startswith('B[') or prop.startswith('W['):
            col = sgf_coordinate_to_index(prop[2])
            row = sgf_coordinate_to_index(prop[3])
            color = 'B' if prop.startswith('B') else 'W'
            # Check if the coordinates are within the valid range
            if 0 <= row < 19 and 0 <= col < 19:
                moves.append((color, (row, col)))
    return moves

def build_final_board(moves):
    """
    Build the final board state from moves.
    """
    board = np.zeros((19, 19), dtype=int)
    for color, (row, col) in moves:
        if (0 <= row < 19) and (0 <= col < 19):
            board[row, col] = sgf_to_array[color]
    return board

def extract_game_result(sgf_content):
    """
    Extract the game result from SGF content.
    """
    result_marker = 'RE['
    start = sgf_content.find(result_marker)
    if start != -1:
        start += len(result_marker)
        end = sgf_content.find(']', start)
        result_string = sgf_content[start:end].strip()
        if result_string.startswith('B'):
            return -1  # Black win
        elif result_string.startswith('W'):
            return 1  # White win
    return 0  # Draw or unknown

# Assuming the SGF files are located in the '2024' directory relative to the current script
sgf_files = glob.glob('2025/**/*.sgf', recursive=True)

# Process each SGF file
features = []
results = []
for sgf_file in sgf_files:
    with open(sgf_file, 'r') as file:
        content = file.read()
        moves = parse_sgf(content)
        final_board = build_final_board(moves)
        features.append(final_board.flatten())  # Flatten the board to 1D array
        game_result = extract_game_result(content)
        results.append(game_result)

# Convert the list of features and results to numpy arrays
feature_array = np.array(features)
target_array = np.array(results)
# Now, you have `feature_array` and `target_array` ready for machine learning training.
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
# 训练模型
rf_classifier.fit(feature_array, target_array)
# 模型训练完成
print("Random Forest model training is complete.")
train_predictions = rf_classifier.predict(feature_array)
train_accuracy = accuracy_score(target_array, train_predictions)
train_error_rate = 1 - train_accuracy
print(f"Training Error Rate: {train_error_rate:.2f}")
# 保存模型，以便之后可以重用，而不需要重新训练
joblib.dump(rf_classifier, 'random_forest_model.joblib')
# 如果你想查看模型的特征重要性
feature_importances = rf_classifier.feature_importances_
print("Feature importances:", feature_importances)


